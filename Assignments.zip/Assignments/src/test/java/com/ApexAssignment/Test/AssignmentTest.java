package com.ApexAssignment.Test;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import net.bytebuddy.implementation.bind.annotation.AllArguments.Assignment;

public class AssignmentTest 
{
	@BeforeTest
	public void create_ExcelFile()
	{
		AssignmentClass.create_Excel();
	}
	@BeforeMethod
	public void launch_Site()
	{
		AssignmentClass.launch_Website();
	}
	
	
	
	
	
	@Test
	public void meth1() throws IOException
	{
		AssignmentClass.write_Data_To_ExcelSheet(0,25);
	}
	@Test
	public void meth2() throws IOException
	{
		AssignmentClass.write_Data_To_ExcelSheet(25,50);
	}
	@Test
	public void meth3() throws IOException
	{
		AssignmentClass.write_Data_To_ExcelSheet(50,75);
	}
	@Test
	public void meth4() throws IOException
	{
		AssignmentClass.write_Data_To_ExcelSheet(75,100);
	}
	
	
	
	
	
	
	 @AfterMethod
	 public void close_Website()
	 {
		 AssignmentClass.close_WebSite();
	 }
	 @AfterTest
	 public void save_Excel()
	 {
		 AssignmentClass.save_Excel();
	 }
}
