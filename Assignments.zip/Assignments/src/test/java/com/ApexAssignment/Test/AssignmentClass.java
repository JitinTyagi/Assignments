package com.ApexAssignment.Test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.NoSuchElementException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AssignmentClass
{

	public static WebDriver driver;
	public static WebDriverWait wait;

	
/********************************locators********************************/		
	public static int index=0;
	
	public static String url="https://www.game.tv/";
	public static String title="Game.tv - Play or Host Mobile Esports Tournaments Run by AI";
	public static By games_List=By.cssSelector(".game-list-wrapper>.games-list>li");
	public static By game_Link=By.cssSelector(".game-list-wrapper>.games-list>li>a");
	public static By games_Names =By.cssSelector(".game-list-wrapper .games-list li a figcaption");
	public static By tournament_Count=By.cssSelector(".count-tournaments");
	public static WebElement games;
	public static  String name;
	public static WebElement temp;
	public static List<String> temp2;
	
	
/********************************locators********************************/		
	

	
	/********************************File********************************/		
	
	
	public static XSSFWorkbook book;
	public static XSSFSheet sheet;
	public static XSSFRow row;
	public static XSSFCell cell;
	public static File  gameData;
	public static FileOutputStream fos;

	
/********************************File********************************/			
	


	

	

	
	
		
	
		

	
	
		
	
	public static int games_Count()
	{
	
		
		List<WebElement> e= wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(games_List));
		
		return e.size();
	}
	
	public static boolean isPresent(By by)
	{
		try
		{
			wait.until(ExpectedConditions.presenceOfElementLocated(by));
			return true;
		}
		
		catch(NoSuchElementException e)
		{
			return false;
		}
	}

	public static void launch_Website()
	{
		WebDriverManager.chromedriver().setup();
		ChromeOptions op=new ChromeOptions();
		op.addArguments("headless");
//		op.addArguments("start-maximized");
		driver=new ChromeDriver(op);
		
		wait=new WebDriverWait(driver,30,2);
	
		driver.get(url);
		System.out.println("WebSite Launched" +driver.getTitle());
		
		}
	
	public static void write_Data_To_ExcelSheet(int k,int l) throws IOException
	{
		
		
		
		
		for(int i=k;i<l;i++)
		{
			try 
			{
			
			
			row=sheet.createRow(i+1);
			
			
			cell=row.createCell(0);
			cell.setCellValue(i+1);
			
			
			cell=row.createCell(1);
			name=wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(games_Names)).get(i).getText();
			cell.setCellValue(name);
		
			System.out.println("Written name"+i);
			
			
			temp=wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(game_Link)).get(i);
			wait.until(ExpectedConditions.elementToBeClickable(temp));
			temp.click();
			
			cell=row.createCell(2);
			cell.setCellValue(driver.getCurrentUrl());
			System.out.println("Url written"+i);
			
			
			cell=row.createCell(3);
			if(isPresent(tournament_Count))
			{
				cell.setCellValue(200);
				System.out.println("Status written"+i);
				cell=row.createCell(4);
				temp=wait.until(ExpectedConditions.presenceOfElementLocated(tournament_Count));
				cell.setCellValue(temp.getText());
				System.out.println("tourney count written"+i);
			}
			else
			{
				continue;
			}
			
			
			
			
			
			driver.navigate().back();
			wait.until(ExpectedConditions.titleContains(title));
			}
			catch(Exception e)
			{
				System.out.print("failure");
				e.printStackTrace();
			}
			
			
			}
	}
	public static void create_Excel()
	{
		gameData=new File(System.getProperty("user.dir")+"\\data.xlsx");
		book=new XSSFWorkbook();
		sheet= book.createSheet("data");
		try {
			fos=new FileOutputStream(gameData);
		} catch (FileNotFoundException e) 
		{
		
			e.printStackTrace();
		}
		row=sheet.createRow(0);
		
		cell=row.createCell(0);
		cell.setCellValue("S No.");
		cell=row.createCell(1);
		cell.setCellValue("Name");
		cell=row.createCell(2);
		cell.setCellValue("URL");
		cell=row.createCell(3);
		cell.setCellValue("Status");
		cell=row.createCell(4);
		cell.setCellValue("Tournament Count");
		System.out.println("excel created");
	}
	public static void save_Excel()
	{
		try {
			book.write(fos);
			fos.close();
			System.out.println("Done");
		}
		catch (IOException e) {
			
			e.printStackTrace();
		}
	}

	public static void close_WebSite()
	{
		driver.quit();
	}
}
